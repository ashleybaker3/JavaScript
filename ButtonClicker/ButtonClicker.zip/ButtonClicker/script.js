function signOut(element) {
    element.innerText = "Sign Out";
}

function hide(element) {
    element.remove();
}