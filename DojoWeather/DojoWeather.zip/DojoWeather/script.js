

function hide(element) {
    var cookies = document.getElementById('cookies');
    cookies.remove();
}
